#ifndef WORDLIST_H
#define WORDLIST_H

#include <QWidget>
#include <QPen>

class WordList : public QWidget
{
    Q_OBJECT
    QVector<QString> userList;
    QVector<QString> compList;
    QVector<QRect> userRects;
    QVector<QRect> compRects;
    QPen pen;
public:
    explicit WordList(QWidget *parent = nullptr);

signals:
public slots:
    void slotUserWord(QString);
    void slotCompWord(QString);
    void slotNewGame();



    // QWidget interface
protected:
    virtual void paintEvent(QPaintEvent *event);
};

#endif // WORDLIST_H
