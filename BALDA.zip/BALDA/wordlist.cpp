#include "wordlist.h"
#include <QPainter>
#include <QDebug>

WordList::WordList(QWidget *parent) : QWidget(parent)
{
    QRect rect = this->rect();
    int width = 120;
    this->setFocusPolicy(Qt::NoFocus);
    //qDebug() << this->rect();
    //qDebug() << "ширина " << width;
    //формируем координаты, в которых будет отображаться список слов
    //хватает на 15 букв
    userRects.reserve(10);
    userRects << QRect(0,0,120, 30) << QRect(0,30,120, 30) << QRect(0,60,120, 30) << QRect(0,90,120, 30)
              << QRect(0,120,120, 30) << QRect(0,150,120, 30) << QRect(0,180,120, 30) << QRect(0,210,120, 30)
              << QRect(0,240,120, 30) << QRect(0,270,120, 30);
    compRects.reserve(10);
    compRects << QRect(width,0,width, 30) << QRect(width,30,width, 30) << QRect(width,60,width, 30) << QRect(width,90,width, 30)
              << QRect(width,120,width, 30) << QRect(width,150,width, 30) << QRect(width,180,width, 30) << QRect(width,210,width, 30)
              << QRect(width,240,width, 30) << QRect(width,270,width, 30);
    pen.setColor(QColor(232,0,0));
}


void WordList::paintEvent(QPaintEvent *event)
{
    //перерисовываем все слова, которые есть в векторах
    QPainter painter(this);
    QFont font("Segoe Print", 12);
    //font.setPointSize(15);
    font.setBold(true);
    painter.setFont(font);
    QPen penRect;
    penRect.setColor(QColor(Qt::white));
    QPen penText;
    penText.setColor(QColor(232,0,0));
    QBrush brush (QColor(Qt::white));
    painter.setBrush(brush);
    for(int i = 0; i < userList.size(); i++)
    {
        painter.setPen(penRect);
        painter.drawRect(userRects[i]);
        painter.setPen(penText);
        painter.drawText(userRects[i], Qt::AlignCenter, userList[i]);
    }
    for(int i = 0; i < compList.size(); i++)
    {
        painter.setPen(penRect);
        painter.drawRect(compRects[i]);
        painter.setPen(penText);
        painter.drawText(compRects[i], Qt::AlignCenter, compList[i]);
    }
}

void WordList::slotUserWord(QString str)
{
    userList.push_back(str);
    this->repaint();
}

void WordList::slotCompWord(QString str)
{
    compList.push_back(str);
    this->repaint();
}

void WordList::slotNewGame()
{
    auto itb1 = userList.begin(), ite1 = userList.end();
    userList.erase(itb1, ite1);
    auto itb2 = compList.begin(), ite2 = compList.end();
    compList.erase(itb2, ite2);
    this->repaint();
}
