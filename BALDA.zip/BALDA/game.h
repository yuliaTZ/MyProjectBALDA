#ifndef GAME_H
#define GAME_H
#include <map>
#include <QString>
#include <QPoint>
#include <QVector>
#include <set>
#include <list>
class Tree;

class Game
{
    std::map<int, QString> mapIntLetter;     //вершины и буквы
    std::map<int, QPoint> mapIntPoint;       //вершины и координаты
    std::map<int, std::set<int>> mapIntSet;  //ГРАФ
    std::map<QString, QVector<QPoint>> allCompWords;    //все слова, найденные компом
    Tree* root;                              //дерево для составления словаря
    QString compWord;
    QVector<QString*> wordbBaseForNewGame;    //база слов для начала игры(только 5ти буквенные)
    QVector<QString> userWords;   //слова, котовые ввел пользователь
    QVector<QString> compWords;   //слова, которые ввел комп
    QVector<QString> lettersBase;   //все буквы, которые будет перебирать компьютер
    int userScore;   //счет игрока
    int compScore;   //счет компьютера
    QVector<int> wordSize;  //переменная содержит разные длины слов, которые нашёл комп, чтобы потом не искать такие же
    QVector<QPoint> compWordCoordinate;     //координаты найденного компом слова
    QVector<int> vecWord;       //переменная для обхода всех вершин графа
    std::list<QPoint> pointsForCompSteps; //координаты клеток, в которые комп может сделать ход


public:
    Game();
    ~Game();
    void makeTree();
    bool checkString(const QString& line);
    void makeGraf(const QPoint& point, const QString& letter);
    void removeFromGraf(int x);
    void traversalGraf();
    void findAllCombinations(int x);
    void chooseBestWord();
    QString& makeNewStartWord();
    bool checkWordInUserCompBase(const QString&); //проверка на введение повторяющихся слов
    void addUserWord(const QString& word);
    void startNewGame();
    const QVector<QPoint>& wordCoordinateGet() const;
    const QString& compWordGet() const;
    bool GameOver();
    int compScoreGet();
    void setUserScore(int);
    int userScoreGet();
    void setPointsForCompStep(const std::list<QPoint>&);

};

#endif // GAME_H
