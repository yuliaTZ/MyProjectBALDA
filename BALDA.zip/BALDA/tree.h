#ifndef TREE_H
#define TREE_H
#include <QString>

const int size = 32;
class Tree
{
    Tree* next[size];
    int strSize;
public:
    Tree();
    ~Tree();
    void addString(QString& line);
    bool checkString(const QString& line);
    bool checkPossibleWord(const QString& line);
    friend void deleteTree(Tree* tree);
};

    void deleteTree(Tree* tree);

#endif // TREE_H
