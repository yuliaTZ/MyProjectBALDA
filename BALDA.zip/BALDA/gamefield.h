#ifndef GAMEFIELD_H
#define GAMEFIELD_H

#include <QWidget>
#include <QPen>
#include "Game.h"


class GameField : public QWidget
{
    Q_OBJECT
    QVector<QVector<QRect>> field;          //игровое поле
    QVector<QVector<QString>> letterArroy;  //массив букв
    int x, y;        //найденные координаты
    int m_x, m_y;    //координаты для проверки, что они были использованы в слове
    QRect rect;      //найденный прямоугольник
    QString letter;  //введенная буква
    QPen penField;   //тип поля
    QPen penRect;    //тип прямоугольника
    QPen penLetter;  //тип буквы
    QString word;    //найденное/введенное слово
    int timer;      //значение таймера
    int count;      //переменная для отображения компом слова на поле
    bool drawLetter;
    bool drawRect;
    bool enterWord;
    bool computerStep;
    bool timerStart; 
    QVector<QPoint> wordCoordinate;     //координаты найденного компом слова
    Game* game;
    QVector<QRect> rectsForWord;  //выделенные прямоугольники для слова
    std::list<QPoint> pointsForCompStep; //координаты клеток, в которые комп может сделать ход


public:
    explicit GameField(QWidget *parent = nullptr);
    ~GameField();
protected:
    const QRect& findRect(QPoint point);    //поиск прямоугольника
    bool checkRect();                //проверяем координаты прямоугольника для составления слова
    bool checkRectCloseToLetter();   //проверяем наличие рядом букв
    bool checkLetterInWord();        //проверяем, вошла ли нарисованная буква в слово
    void findAvailable();            //ищем клетки, в которые компьютер может поместить буквы
    void formCompWord();
    void afterStopTimer();
    void drawNewStartWord();
    void gameOver();

signals:
    void signalWord(QString);
    void signalUserScore(int);
    void signalCompScore(int);
    void signalUserWord(QString);
    void signalCompWord(QString);

public slots:
    void slotEnter();
    void slotClear();
    void slotNewGame();

    // QWidget interface
protected:
    virtual void paintEvent(QPaintEvent *event);
    virtual void mousePressEvent(QMouseEvent *event);
    virtual void keyPressEvent(QKeyEvent *event);

    // QObject interface
protected:
    virtual void timerEvent(QTimerEvent *event);
};

#endif // GAMEFIELD_H
