#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QMessageBox>
#include <QDesktopServices>
#include <QUrl>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setFocusPolicy(Qt::NoFocus);
    Qt::WindowFlags flags = Qt::Widget;
    flags |= Qt::WindowCloseButtonHint;
    flags |= Qt::WindowMinimizeButtonHint;
    this->setWindowFlags(flags);

    ui->gridLayout->setAlignment(ui->lcdNumberUser, Qt::AlignHCenter);
    ui->gridLayout->setAlignment(ui->lcdNumberComp, Qt::AlignHCenter);
    ui->gridLayout->setAlignment(ui->pushButtonClear, Qt::AlignHCenter);
    ui->gridLayout->setAlignment(ui->pushButtonEnter, Qt::AlignHCenter);
    ui->gridLayout->setAlignment(ui->widget, Qt::AlignHCenter);
    ui->gridLayout->setAlignment(ui->label, Qt::AlignHCenter);
    ui->gridLayout->setAlignment(ui->label_1, Qt::AlignHCenter);
    ui->gridLayout->setAlignment(ui->label_2, Qt::AlignHCenter);
    ui->gridLayout_2->setAlignment(ui->widget_2, Qt::AlignHCenter);
    ui->gridLayout_2->setAlignment(ui->label_3, Qt::AlignHCenter);
    ui->gridLayout_2->setAlignment(ui->label_4, Qt::AlignHCenter);
    ui->gridLayout_2->setAlignment(ui->label_5, Qt::AlignHCenter);
    QSize size = this->sizeHint();
    qDebug()<<size;
    this->setFixedSize(size);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::openRules()
{
    QDesktopServices::openUrl(QUrl::fromLocalFile("rules.txt"));
}

void MainWindow::aboutProgram()
{
    QMessageBox::information(this, QStringLiteral("О программе"), QStringLiteral("Разработано для ВКР by TZ"));
}
