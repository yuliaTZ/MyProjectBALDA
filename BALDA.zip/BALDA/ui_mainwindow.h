/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.14.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>
#include "gamefield.h"
#include "wordlist.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *action_New_game;
    QAction *action_Exit;
    QAction *action_Game_rule;
    QAction *action_About_program;
    QWidget *centralwidget;
    QHBoxLayout *horizontalLayout_2;
    QHBoxLayout *horizontalLayout;
    QGridLayout *gridLayout;
    GameField *widget;
    QLabel *label;
    QPushButton *pushButtonEnter;
    QPushButton *pushButtonClear;
    QLabel *label_1;
    QLabel *label_2;
    QLCDNumber *lcdNumberUser;
    QLCDNumber *lcdNumberComp;
    QGridLayout *gridLayout_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    WordList *widget_2;
    QMenuBar *menubar;
    QMenu *menu_File;
    QMenu *menu_File_2;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(558, 518);
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/Icons/exe/icon.ico"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        MainWindow->setStyleSheet(QString::fromUtf8("background-image: url(:/Images/exe/flower6.jpg);"));
        MainWindow->setIconSize(QSize(32, 32));
        action_New_game = new QAction(MainWindow);
        action_New_game->setObjectName(QString::fromUtf8("action_New_game"));
        action_Exit = new QAction(MainWindow);
        action_Exit->setObjectName(QString::fromUtf8("action_Exit"));
        action_Exit->setCheckable(true);
        action_Game_rule = new QAction(MainWindow);
        action_Game_rule->setObjectName(QString::fromUtf8("action_Game_rule"));
        action_About_program = new QAction(MainWindow);
        action_About_program->setObjectName(QString::fromUtf8("action_About_program"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        horizontalLayout_2 = new QHBoxLayout(centralwidget);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        widget = new GameField(centralwidget);
        widget->setObjectName(QString::fromUtf8("widget"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(widget->sizePolicy().hasHeightForWidth());
        widget->setSizePolicy(sizePolicy1);
        widget->setMinimumSize(QSize(260, 260));
        widget->setMaximumSize(QSize(1000000, 260));

        gridLayout->addWidget(widget, 0, 0, 1, 2);

        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        sizePolicy1.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy1);
        label->setMinimumSize(QSize(260, 30));
        label->setMaximumSize(QSize(10000000, 16777215));
        QPalette palette;
        QBrush brush(QColor(0, 0, 0, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        QBrush brush1(QColor(120, 120, 120, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
        label->setPalette(palette);
        QFont font;
        font.setFamily(QString::fromUtf8("Segoe Print"));
        font.setPointSize(11);
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        label->setFrameShape(QFrame::Box);
        label->setFrameShadow(QFrame::Sunken);
        label->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label, 1, 0, 1, 2);

        pushButtonEnter = new QPushButton(centralwidget);
        pushButtonEnter->setObjectName(QString::fromUtf8("pushButtonEnter"));
        sizePolicy1.setHeightForWidth(pushButtonEnter->sizePolicy().hasHeightForWidth());
        pushButtonEnter->setSizePolicy(sizePolicy1);
        pushButtonEnter->setMinimumSize(QSize(120, 30));
        pushButtonEnter->setMaximumSize(QSize(1000000, 100000));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Segoe Print"));
        font1.setPointSize(11);
        font1.setBold(true);
        font1.setWeight(75);
        font1.setKerning(true);
        pushButtonEnter->setFont(font1);

        gridLayout->addWidget(pushButtonEnter, 2, 0, 1, 1);

        pushButtonClear = new QPushButton(centralwidget);
        pushButtonClear->setObjectName(QString::fromUtf8("pushButtonClear"));
        sizePolicy1.setHeightForWidth(pushButtonClear->sizePolicy().hasHeightForWidth());
        pushButtonClear->setSizePolicy(sizePolicy1);
        pushButtonClear->setMinimumSize(QSize(120, 30));
        pushButtonClear->setMaximumSize(QSize(10000000, 16777215));
        pushButtonClear->setFont(font);

        gridLayout->addWidget(pushButtonClear, 2, 1, 1, 1);

        label_1 = new QLabel(centralwidget);
        label_1->setObjectName(QString::fromUtf8("label_1"));
        sizePolicy1.setHeightForWidth(label_1->sizePolicy().hasHeightForWidth());
        label_1->setSizePolicy(sizePolicy1);
        label_1->setMinimumSize(QSize(120, 30));
        label_1->setMaximumSize(QSize(10000000, 16777215));
        label_1->setFont(font);
        label_1->setFrameShape(QFrame::NoFrame);
        label_1->setFrameShadow(QFrame::Sunken);
        label_1->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_1, 3, 0, 1, 1);

        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        sizePolicy1.setHeightForWidth(label_2->sizePolicy().hasHeightForWidth());
        label_2->setSizePolicy(sizePolicy1);
        label_2->setMinimumSize(QSize(120, 30));
        label_2->setMaximumSize(QSize(10000000, 16777215));
        label_2->setFont(font);
        label_2->setFrameShape(QFrame::NoFrame);
        label_2->setFrameShadow(QFrame::Sunken);
        label_2->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(label_2, 3, 1, 1, 1);

        lcdNumberUser = new QLCDNumber(centralwidget);
        lcdNumberUser->setObjectName(QString::fromUtf8("lcdNumberUser"));
        sizePolicy1.setHeightForWidth(lcdNumberUser->sizePolicy().hasHeightForWidth());
        lcdNumberUser->setSizePolicy(sizePolicy1);
        lcdNumberUser->setMinimumSize(QSize(65, 30));
        lcdNumberUser->setMaximumSize(QSize(65, 16777215));
        lcdNumberUser->setLayoutDirection(Qt::LeftToRight);

        gridLayout->addWidget(lcdNumberUser, 4, 0, 1, 1, Qt::AlignHCenter);

        lcdNumberComp = new QLCDNumber(centralwidget);
        lcdNumberComp->setObjectName(QString::fromUtf8("lcdNumberComp"));
        sizePolicy1.setHeightForWidth(lcdNumberComp->sizePolicy().hasHeightForWidth());
        lcdNumberComp->setSizePolicy(sizePolicy1);
        lcdNumberComp->setMinimumSize(QSize(65, 30));
        lcdNumberComp->setMaximumSize(QSize(65, 16777215));
        QPalette palette1;
        palette1.setBrush(QPalette::Active, QPalette::Text, brush);
        QBrush brush2(QColor(0, 0, 0, 128));
        brush2.setStyle(Qt::SolidPattern);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette1.setBrush(QPalette::Active, QPalette::PlaceholderText, brush2);
#endif
        palette1.setBrush(QPalette::Inactive, QPalette::Text, brush);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette1.setBrush(QPalette::Inactive, QPalette::PlaceholderText, brush2);
#endif
        palette1.setBrush(QPalette::Disabled, QPalette::Text, brush1);
#if QT_VERSION >= QT_VERSION_CHECK(5, 12, 0)
        palette1.setBrush(QPalette::Disabled, QPalette::PlaceholderText, brush2);
#endif
        lcdNumberComp->setPalette(palette1);

        gridLayout->addWidget(lcdNumberComp, 4, 1, 1, 1, Qt::AlignHCenter);


        horizontalLayout->addLayout(gridLayout);

        gridLayout_2 = new QGridLayout();
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        sizePolicy1.setHeightForWidth(label_3->sizePolicy().hasHeightForWidth());
        label_3->setSizePolicy(sizePolicy1);
        label_3->setMinimumSize(QSize(240, 30));
        label_3->setMaximumSize(QSize(1000000, 16777215));
        QPalette palette2;
        palette2.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette2.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette2.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
        label_3->setPalette(palette2);
        label_3->setFont(font);
        label_3->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(label_3, 0, 0, 1, 2);

        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        sizePolicy1.setHeightForWidth(label_4->sizePolicy().hasHeightForWidth());
        label_4->setSizePolicy(sizePolicy1);
        label_4->setMinimumSize(QSize(120, 30));
        label_4->setMaximumSize(QSize(100000, 16777215));
        QPalette palette3;
        palette3.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette3.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette3.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
        label_4->setPalette(palette3);
        label_4->setFont(font);
        label_4->setFrameShape(QFrame::NoFrame);
        label_4->setFrameShadow(QFrame::Sunken);
        label_4->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(label_4, 1, 0, 1, 1);

        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        sizePolicy1.setHeightForWidth(label_5->sizePolicy().hasHeightForWidth());
        label_5->setSizePolicy(sizePolicy1);
        label_5->setMinimumSize(QSize(120, 30));
        label_5->setMaximumSize(QSize(100000, 1000000));
        QPalette palette4;
        palette4.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette4.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette4.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
        label_5->setPalette(palette4);
        label_5->setFont(font);
        label_5->setFrameShape(QFrame::NoFrame);
        label_5->setFrameShadow(QFrame::Sunken);
        label_5->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(label_5, 1, 1, 1, 1);

        widget_2 = new WordList(centralwidget);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        sizePolicy1.setHeightForWidth(widget_2->sizePolicy().hasHeightForWidth());
        widget_2->setSizePolicy(sizePolicy1);
        widget_2->setMinimumSize(QSize(240, 380));
        widget_2->setMaximumSize(QSize(1000000, 1000000));

        gridLayout_2->addWidget(widget_2, 2, 0, 1, 2);


        horizontalLayout->addLayout(gridLayout_2);


        horizontalLayout_2->addLayout(horizontalLayout);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 558, 21));
        menu_File = new QMenu(menubar);
        menu_File->setObjectName(QString::fromUtf8("menu_File"));
        menu_File_2 = new QMenu(menubar);
        menu_File_2->setObjectName(QString::fromUtf8("menu_File_2"));
        MainWindow->setMenuBar(menubar);

        menubar->addAction(menu_File->menuAction());
        menubar->addAction(menu_File_2->menuAction());
        menu_File->addAction(action_New_game);
        menu_File->addAction(action_Exit);
        menu_File_2->addAction(action_Game_rule);
        menu_File_2->addAction(action_About_program);

        retranslateUi(MainWindow);
        QObject::connect(action_New_game, SIGNAL(triggered()), widget_2, SLOT(slotNewGame()));
        QObject::connect(action_Exit, SIGNAL(triggered()), MainWindow, SLOT(close()));
        QObject::connect(action_Game_rule, SIGNAL(triggered()), MainWindow, SLOT(openRules()));
        QObject::connect(widget, SIGNAL(signalWord(QString)), label, SLOT(setText(QString)));
        QObject::connect(widget, SIGNAL(signalUserScore(int)), lcdNumberUser, SLOT(display(int)));
        QObject::connect(pushButtonClear, SIGNAL(clicked()), widget, SLOT(slotClear()));
        QObject::connect(widget, SIGNAL(signalUserWord(QString)), widget_2, SLOT(slotUserWord(QString)));
        QObject::connect(widget, SIGNAL(signalCompWord(QString)), widget_2, SLOT(slotCompWord(QString)));
        QObject::connect(action_New_game, SIGNAL(triggered()), widget, SLOT(slotNewGame()));
        QObject::connect(pushButtonEnter, SIGNAL(clicked()), widget, SLOT(slotEnter()));
        QObject::connect(widget, SIGNAL(signalCompScore(int)), lcdNumberComp, SLOT(display(int)));
        QObject::connect(action_About_program, SIGNAL(triggered()), MainWindow, SLOT(aboutProgram()));

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "\320\221\320\220\320\233\320\224\320\220", nullptr));
        action_New_game->setText(QCoreApplication::translate("MainWindow", "\320\235\320\276\320\262\320\260\321\217 \320\270\320\263\321\200\320\260", nullptr));
        action_New_game->setIconText(QCoreApplication::translate("MainWindow", "\320\235\320\276\320\262\320\260\321\217 \320\270\320\263\321\200\320\260", nullptr));
#if QT_CONFIG(tooltip)
        action_New_game->setToolTip(QCoreApplication::translate("MainWindow", "\320\235\320\276\320\262\320\260\321\217 \320\270\320\263\321\200\320\260", nullptr));
#endif // QT_CONFIG(tooltip)
#if QT_CONFIG(shortcut)
        action_New_game->setShortcut(QCoreApplication::translate("MainWindow", "Ctrl+N", nullptr));
#endif // QT_CONFIG(shortcut)
        action_Exit->setText(QCoreApplication::translate("MainWindow", "\320\222\321\213\321\205\320\276\320\264", nullptr));
        action_Exit->setIconText(QCoreApplication::translate("MainWindow", "\320\222\321\213\321\205\320\276\320\264", nullptr));
#if QT_CONFIG(tooltip)
        action_Exit->setToolTip(QCoreApplication::translate("MainWindow", "\320\222\321\213\321\205\320\276\320\264", nullptr));
#endif // QT_CONFIG(tooltip)
        action_Game_rule->setText(QCoreApplication::translate("MainWindow", "\320\237\321\200\320\260\320\262\320\270\320\273\320\260 \320\270\320\263\321\200\321\213", nullptr));
        action_About_program->setText(QCoreApplication::translate("MainWindow", "\320\236 \320\277\321\200\320\276\320\263\321\200\320\260\320\274\320\274\320\265", nullptr));
        label->setText(QString());
        pushButtonEnter->setText(QCoreApplication::translate("MainWindow", "\320\222\320\222\320\225\320\241\320\242\320\230 ", nullptr));
        pushButtonClear->setText(QCoreApplication::translate("MainWindow", "\320\236\320\247\320\230\320\241\320\242\320\230\320\242\320\254", nullptr));
        label_1->setText(QCoreApplication::translate("MainWindow", "\320\222\320\253", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "\320\232\320\236\320\234\320\237\320\254\320\256\320\242\320\225\320\240", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "\320\222\320\222\320\225\320\224\320\225\320\235\320\235\320\253\320\225 \320\241\320\233\320\236\320\222\320\220", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "\320\222\320\253", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "\320\232\320\236\320\234\320\237\320\254\320\256\320\242\320\225\320\240", nullptr));
        menu_File->setTitle(QCoreApplication::translate("MainWindow", "\320\234\320\265\320\275\321\216", nullptr));
        menu_File_2->setTitle(QCoreApplication::translate("MainWindow", "\320\241\320\277\321\200\320\260\320\262\320\272\320\260", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
