#include "tree.h"
#include <QDebug>
#include <new.h>

Tree::Tree()
{
    for(int i = 0; i < 32; i++)
    {
        next[i] = nullptr;
    }
    strSize = 0;
}

Tree::~Tree()
{
    deleteTree(this);
}

void deleteTree(Tree* tree)
{
    if(tree)
    {
        for(int i = 0; i < 32; i++)
        {
            if(tree->next[i])
            {
                deleteTree(tree->next[i]);
                //qDebug()<<"DELETE"<<tree->next[i];
                delete tree->next[i];
                tree->next[i] = nullptr;
            }
        }
        //delete tree;
    }
}

void Tree::addString(QString& line)
{
   Tree* current = this;
   int n = line.size();
   for (int i = 0; i < n; i++)
   {
       int symbol = line[i].unicode() - 0x0430;
       //qDebug()<<symbol;
       if(current->next[symbol] == nullptr)
       {
           //qDebug()<<"COUNT"<<count;
           try{
           current->next[symbol] = new Tree;}
           catch(std::bad_alloc)
           {
               qDebug()<<"BAD ALLOC";
           }
       }
       current = current->next[symbol];
   }
   current->strSize++;
}

bool Tree::checkString(const QString& line)
{
    QString string = line.toLower();
    Tree* current = this;
    int n = line.size();
    for(int i = 0; i < n; i++)
    {
        current = current->next[string[i].unicode() - 0x0430];
        if(current == nullptr)
        {
            return false;
        }
    }
    if (current->strSize != 0) {return true;}
    return false;
}

bool Tree::checkPossibleWord(const QString& line)
{
    QString string = line.toLower();
    Tree* current = this;
    int n = line.size();
    for(int i = 0; i < n; i++)
    {
        current = current->next[string[i].unicode() - 0x0430];
        if(current == nullptr)
        {
            return false;
        }
    }
    return true;
}
