#include "gamefield.h"
#include <QPainter>
#include <QMouseEvent>
#include <QDebug>
#include <QMessageBox>



GameField::GameField(QWidget *parent) : QWidget(parent)
{
   // srand(time(0));
        //инициализация поля
    field.resize(5);
    field[0] << QRect(5,5, 50,50)<< QRect(55,5,50,50)<<QRect(105,5,50,50)<<QRect(155,5,50,50)<<QRect(205,5,50,50);
    field[1] << QRect(5,55, 50,50)<< QRect(55,55,50,50)<<QRect(105,55,50,50)<<QRect(155,55,50,50)<<QRect(205,55,50,50);
    field[2] << QRect(5,105, 50,50)<< QRect(55,105,50,50)<<QRect(105,105,50,50)<<QRect(155,105,50,50)<<QRect(205,105,50,50);
    field[3] << QRect(5,155, 50,50)<< QRect(55,155,50,50)<<QRect(105,155,50,50)<<QRect(155,155,50,50)<<QRect(205,155,50,50);
    field[4] << QRect(5,205, 50,50)<< QRect(55,205,50,50)<<QRect(105,205,50,50)<<QRect(155,205,50,50)<<QRect(205,205,50,50);
        //установка фокуса и отслеживание мыши
    this->setFocusPolicy(Qt::StrongFocus);
    //this->setFocus(Qt::PopupFocusReason);
    this->setMouseTracking(true);
    drawRect = false;
    drawLetter = false;
    enterWord = false;
    computerStep = false;
    timerStart = false;
    count = 0;
        //инициализация массива букв
    letterArroy.resize(5);
    for(int i = 0; i< letterArroy.size(); i++)
    {
        letterArroy[i].resize(5);
    }
        //установка типов пера
    penField.setColor(QColor(40,139,180));
    penField.setWidth(5);
    penRect.setColor(QColor(57,213,57));
    penRect.setWidth(5);
    penLetter.setColor(QColor(255, 218, 9));
        //создаём игру с компьютером
    game = new Game;
        //формируем стартовое слово
    this->drawNewStartWord();
}

GameField::~GameField()
{   
    delete game;
}

void GameField::paintEvent(QPaintEvent *event)
{
    //рисуем поле и текст на нём
    QPainter paintField(this);
    paintField.setPen(penField);
    for(auto it: field)
    {
        paintField.drawRects(it);
    }
    //текст
    QFont fontText;
    fontText.setPointSize(30);
    fontText.setBold(true);
    paintField.setPen(penLetter);
    paintField.setFont(fontText);
    for(int i = 0; i< 5; i ++)
        for (int j = 0; j< 5; j++)
        {
            paintField.drawText(field[i][j], Qt::AlignCenter, letterArroy[i][j]);
        }
    //рисуем выделенный прямоугольник
    if((drawRect == true) && (enterWord == false))
    {
        paintField.setPen(penRect);
        paintField.drawRect(rect);
    }
    //рисуем букву
    if(drawLetter == true)
    {
        paintField.setPen(penLetter);
        paintField.drawText(rect, Qt::AlignCenter, letter);
        drawLetter = false;
    }
    //выделяем слово
    if((drawRect == false) && (enterWord == true))
    {
        QBrush brush(QColor(175,210,216));
        paintField.setBrush(brush);
        paintField.setPen(penRect);
        paintField.drawRects(rectsForWord);
        paintField.setPen(penLetter);
        for(auto it: rectsForWord)
        {
            paintField.drawText(it, Qt::AlignCenter, letterArroy[it.topLeft().y()/50][it.topLeft().x()/50]);
        }

    }
    //ход компьютера, выделяем слово
    if(timerStart == true)
    {
        QBrush brush(QColor(175,210,216));
        paintField.setBrush(brush);
        paintField.setPen(penRect);
        paintField.drawRects(rectsForWord);
        paintField.setPen(penLetter);
        for(auto it: rectsForWord)
        {
            paintField.drawText(it, Qt::AlignCenter, letterArroy[it.topLeft().y()/50][it.topLeft().x()/50]);
        }
        emit (this->signalWord(word));
    }
}

void GameField::mousePressEvent(QMouseEvent *event)
{
    if(computerStep == false)
    {
    if(Qt::LeftButton & event->button())
    {
            //вводим просто букву
        if(enterWord == false)
        {

            QPoint globalPoint = QCursor::pos();
            QPoint rectPoint = this->mapFromGlobal(globalPoint);
            rect = this->findRect(rectPoint);
            if(x != -1)
            {
            if(letterArroy[x][y].isEmpty() && this->checkRectCloseToLetter())  //если в данной клекте отсутствует текст, то перерисовываем
            {
               drawRect = true;
               this->repaint();
            }
            else
            {
                drawRect = false;
                drawLetter = false;
            }
            }
        }
            //вводим слово
        else if(enterWord == true)
        {
            QPoint globalPoint = QCursor::pos();
            QPoint rectPoint = this->mapFromGlobal(globalPoint);
            rect = this->findRect(rectPoint);
            if(x != -1)
            {
            if(letterArroy[x][y].isEmpty() == false)
            {
                if(rectsForWord.isEmpty() == true)  //если в слове еще нет букв
                {
                    rectsForWord.push_back(rect);   //заносим первую
                    word = letterArroy[x][y];
                    emit (this->signalWord (word));  //сигнал для отображения слова
                    qDebug() << word;
                    this->repaint();
                }
                else if(rectsForWord.isEmpty() == false)  //если в слове уже есть буквы
                {
                    //надо сделать проверку, что квадрат выбран не по диагонали относительно предыдущего
                    if(this->checkRect())
                    {
                        rectsForWord.push_back(rect);
                        word += letterArroy[x][y];
                        emit (this->signalWord (word));  //сигнал для отображения слова
                        qDebug() << word;
                        this->repaint();
                    }
                }
            }
            }
        }
        }
    }
    else if(computerStep == true)
    {
        QWidget::mousePressEvent(event);
        return;
    }
}

bool GameField::checkRect()
{
    //проверка на нажатие одного и того же квадрата два раза
    for(auto it: rectsForWord)
    {
        if(it == rect)
            return false;
    }

    //запрет нажатия по диагонали
    if((y - 1) >= 0)
    {
        if(field[x][y-1] == rectsForWord.last())
            return true;
    }
    if((x - 1) >= 0)
    {
        if(field[x-1][y] == rectsForWord.last())
            return true;
    }
    if((y + 1) <= 4)
    {
        if(field[x][y+1] == rectsForWord.last())
            return true;
    }
    if((x + 1) <= 4)
    {
        if(field[x+1][y] == rectsForWord.last())
            return true;
    }
    return false;
}

bool GameField::checkLetterInWord()        //проверяем, вошла ли нарисованная буква в слово
{
    for(auto it: rectsForWord)
    {
        if(it == field[m_x][m_y])
        {
            return true;
        }
    }
    return false;
}

bool GameField::checkRectCloseToLetter()   //проверяем наличие рядом букв
{
    if((y - 1) >= 0)
    {
        if(letterArroy[x][y-1].isEmpty() == false)
            return true;
    }
    if((x - 1) >= 0)
    {
        if(letterArroy[x-1][y].isEmpty() == false)
            return true;
    }
    if((y + 1) <= 4)
    {
        if(letterArroy[x][y+1].isEmpty() == false)
            return true;
    }
    if((x + 1) <= 4)
    {
        if(letterArroy[x+1][y].isEmpty() == false)
            return true;
    }
    return false;
}

const QRect& GameField::findRect(QPoint point)
{
    for(int i = 0; i < 5; i++)
    {
        for(int j = 0; j < 5; j++)
        {
            if((point.x() <= field[i][j].topRight().x()) && (point.x()>=field[i][j].topLeft().x()) &&
              (point.y()<=field[i][j].bottomLeft().y()) && (point.y()>=field[i][j].topLeft().y()))
            {
                qDebug() << i << j;
                x = i;  //запоминаем координаты найденого прямоугольника
                y = j;
                return field[i][j];
            }
        }
    }
    x = -1;
}

//ввод всех букв с клавиатуры
void GameField::keyPressEvent(QKeyEvent *event)
{
    if(computerStep == false)
    {if((drawRect == true ) && (enterWord == false))
    {
            if((*event->text().unicode() >= 0x0410) && (*event->text().unicode() <= 0x042F))
            {
                drawLetter = true;
                letter = event->text();
                this->repaint();
            }
            else if((*event->text().unicode() >= 0x430) && (*event->text().unicode() <= 0x044F))
            {
                drawLetter = true;
                letter = QChar(event->text()[0].unicode() - 0x0020);
                this->repaint();
            }
            else
            {
                return;
            }
    }
    else if((drawRect == false) && (enterWord == true))
    {
        return;
    }
    else if((drawRect == false) && (enterWord == false))
    {
        return;
    }

    //после ввода буквы необходимо ввести слово
    drawRect = false;
    drawLetter = false;
    letterArroy[x][y] = letter;  //сохраняем букву
    letter = "";    //обнуляем текущую букву
    m_x = x;        //запоминаем координаты
    m_y = y;
    this->repaint();   //перерисовываем
    enterWord = true;  //после того, как поставили букву - вводим слово
    }
}

void GameField::slotEnter()
{
    if(computerStep == false)
    {
        if(enterWord == false)
    { // заглушка, ничего не делаем
        QMessageBox::information(this, QStringLiteral("Сообщение"), QStringLiteral("Вы не ввели слово!"));
    }
    if(enterWord == true)  //если слово вводим
    {
       if(word.isEmpty())  //проверка пустое слово или нет
       {
           //если слово пустое, то выдаем сообщение о том, что слово не вводилось
          QMessageBox::information(this, QStringLiteral("Сообщение"), QStringLiteral("Вы не ввели слово!"));
       }
       else   //если слово не пустое
       {
          if(this->checkLetterInWord() == true)  //проверка вошла ли буква в введенное слово
          {
              //если вошла
              //проверяем, не вводилось ли это слово раньше
              if(game->checkWordInUserCompBase(word) == false)
              {
                    //если не вводилось
                  //проверяем есть ли такое слово в базе
                  bool checkWord = game->checkString(word);
                if(checkWord == true)
                {
                        //если слово есть в базе, формируем граф
                    game->makeGraf(QPoint(m_x, m_y), letterArroy[m_x][m_y]);
                    qDebug() << word;
                        //особождаем вектор прямоугольников слова
                    auto itb = rectsForWord.begin(), ite = rectsForWord.end();
                    rectsForWord.erase(itb, ite);
                        //увеличиваем счет
                    game->setUserScore(word.size());
                        //сигнал для отображения счета
                    emit (this->signalUserScore(game->userScoreGet()));
                        //добавляем слово в базу найденных слов пользователя
                    game->addUserWord(word);
                        //сигнал для отрисовки слова сбоку поля
                    emit (this->signalUserWord(word));
                        //перерисовываем для того, чтобы поле выглядело без выделенных квадратов
                    this->repaint();
                        //обнуляем слово
                    word = "";
                        //вводить слово закончили
                    enterWord = false;
                        //ХОД КОМПЬЮТЕРА
                    computerStep = true;
                    this->setFocusPolicy(Qt::NoFocus);
                        //находим все смежные клетки
                    this->findAvailable();
                        //передаём их на обработку
                    game->setPointsForCompStep(pointsForCompStep);
                        //обходим граф
                    game->traversalGraf();
                        //формируем слово, найденное компом, для отрисовки его на поле
                    this->formCompWord();
                       //запускаем таймер, чтобы комп отрисовал найденное им слово
                    timerStart = true;
                    timer = this->startTimer(500);
                }
                else if(checkWord == false)
                {
                        //если такого слова нет в базе, выдаем сообщение об этом
                    QMessageBox::information(this, QStringLiteral("Сообщение"), QStringLiteral("Такого слова нет в словаре!"));
                }
              }
              else if(game->checkWordInUserCompBase(word) == true)
              {
                  //если такое слово уже вводилось, выводим сообщение
                  QMessageBox::information(this, QStringLiteral("Сообщение"), QStringLiteral("Такое слово уже было!"));
              }
          }
          else if(this->checkLetterInWord() == false)
          {
              //если введенной буквы нет в выделенном слове
              QMessageBox::information(this, QStringLiteral("Сообщение"), QStringLiteral("Необходимо использовать введенную букву!"));
          }
       }
    }
    }
}

void GameField::slotClear()
{
    if(computerStep == false)
    {if(enterWord == false)  //если слово не вводим
    {
        //letter = "";        //очищаем букву
        //drawLetter = false;
    }
    if(enterWord == true)  //если слово вводим
    {
        enterWord = false;  //очищаем вводимое слово
        letter = "";
        letterArroy[m_x][m_y] = "";  //очищаем введенную букву
        word = "";
        emit (this->signalWord (word));  //сигнал для отображения слова
        auto itb = rectsForWord.begin(), ite = rectsForWord.end();  //очищаем выбранные прямоугольники
        rectsForWord.erase(itb, ite);
    }
    this->repaint();
    }
}

void GameField::findAvailable()         //ищем клетки, в которые компьютер может поместить буквы
{
    auto itb = pointsForCompStep.begin(), ite = pointsForCompStep.end();
    pointsForCompStep.erase(itb, ite);
    for(int i = 0; i < 5; i++)  //перебираем массив букв
    {    for(int j = 0; j < 5; j++)
         {
            if(letterArroy[i][j].isEmpty())  //если клетка свободная
            {
                //проверяем наличие рядом занятых клеток
                if((j - 1) >= 0)
                {
                    if(letterArroy[i][j-1].isEmpty() == false)  //если рядом клетка занята, то
                    {
                        //вносим в базу
                        pointsForCompStep.push_back(QPoint(i ,j));
                    }
                }
                if((i - 1) >= 0)
                {
                    if(letterArroy[i-1][j].isEmpty() == false)
                    {
                            pointsForCompStep.push_back(QPoint(i ,j));
                    }
                }
                if((j + 1) <= 4)
                {
                    if(letterArroy[i][j+1].isEmpty() == false)
                    {
                            pointsForCompStep.push_back(QPoint(i ,j));
                    }
                }
                if((i + 1) <= 4)
                {
                    if(letterArroy[i+1][j].isEmpty() == false)
                    {
                            pointsForCompStep.push_back(QPoint(i ,j));
                    }
                }
            }
         }
    }
    //удаляем дубли
    pointsForCompStep.unique();
}

void GameField::slotNewGame()
{
    drawRect = false;
    drawLetter = false;
    enterWord = false;
    computerStep = false;
    emit(this->signalUserScore(0));
    emit(this->signalCompScore(0));
    word = "";
    emit(this->signalWord(word));
    //очищаем поле игры
    for(int i = 0; i < 5; i++)
    {
        for(int j = 0; j < 5; j++)
        {
            letterArroy[i][j] = "";
        }
    }
    //формируем новое слово для игры
    this->drawNewStartWord();
}

void GameField::formCompWord()
{
    word = game->compWordGet();
    qDebug()<<"ПОЛУЧИЛИ СЛОВО"<<word;
    if(word == "")
    {
        this->gameOver();
    }
    else
    {
    wordCoordinate = game->wordCoordinateGet();
    qDebug()<<"ПОЛУЧИЛИ КООРДИНАТЫ"<<wordCoordinate;
    for (int i = 0; i< wordCoordinate.size(); i++)
    {
        QPoint point = wordCoordinate[i];
        if(letterArroy[point.x()][point.y()].isEmpty() == true)
        {
            //нашли букву
            letter = word[i];
            //вставили ее в массив
            letterArroy[point.x()][point.y()] = letter;
            //нашли квадрат с этой буквой
            rect = field[point.x()][point.y()];
            //добавили в граф
            game->makeGraf(point, letter);
            //вышли из цикла
            break;
        }
    }
    word = "";
    }
}

void GameField::timerEvent(QTimerEvent *event)
{
    if(count >= wordCoordinate.size())
    {
        this->afterStopTimer();
    }
    if(count != wordCoordinate.size())
    {
        QPoint point = wordCoordinate[count];
        rectsForWord.push_back(field[point.x()][point.y()]);
        word += letterArroy[point.x()][point.y()];
        this->repaint();
        count++;
    }

}

void GameField::afterStopTimer()
{
    //qDebug()<<"ОСТАНОВИЛИ ТАЙМЕР";
    this->killTimer(timer);
    timerStart = false;
    count = 0;
    qDebug()<<"count"<<count;
    wordCoordinate.clear();
    //сигнал для отображения счета
    emit (this->signalCompScore(game->compScoreGet()));
    //сигнал для отображения слова компа в списке найденных слов
    emit (this->signalCompWord(word));
    //окончание хода компа
    computerStep = false;
    //обнуляем слово
    word = "";
    //освобождаем прямоугольники для слова
    rectsForWord.clear();
    //перерисовываем
    this->repaint();
    //проверка на конец игры
    this->gameOver();
    this->setFocusPolicy(Qt::StrongFocus);
}

void GameField::drawNewStartWord()
{
    game->startNewGame();
    word = game->makeNewStartWord();
    word = word.toUpper();
    int i = 0;
    for(auto it: word)
    {
        letterArroy[2][i] = it;
        //на каждой итерации формируем граф
        game->makeGraf(QPoint(2,i), it);
        i++;
    }
    this->repaint();
}

void GameField::gameOver()
{
    if(game->GameOver())
    {
    if(game->userScoreGet() > game->compScoreGet())
    {
        QMessageBox::information(this, QString("Игра закончена"), QString("Поздравляем, Вы выиграли!"));
    }
    else if(game->userScoreGet() < game->compScoreGet())
    {
        QMessageBox::information(this, QString("Игра закончена"), QString("Вы проиграли!"));
    }
    else
    {
        QMessageBox::information(this, QString("Игра закончена"), QString("Ничья!"));
    }
    }
}


