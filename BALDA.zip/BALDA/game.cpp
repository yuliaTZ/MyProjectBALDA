#include "game.h"
#include <QFile>
#include <QTextStream>
#include "Tree.h"
#include <QMessageBox>
#include <stack>
#include <QDebug>

Game::Game()
{
    srand(time(0));
        //создаем из словаря префиксное дерево
    this->makeTree();
        //формируем буквы в базу для компьютера
    lettersBase << "Й" << "Ц" << "У" << "К" << "Е" << "Н" << "Г" << "Ш" << "Щ" << "З" << "Х" << "Ъ" << "Ф" << "Ы"
            << "В" << "А" << "П" << "Р" << "О" << "Л" << "Д" << "Ж" << "Э" << "Я" << "Ч" << "С" << "М" << "И"
            << "Т" << "Ь" << "Б" << "Ю";
        //установка счета
    userScore = 0;
    compScore = 0;
}

Game::~Game()
{
    delete root;
    for(auto it: wordbBaseForNewGame)
    {
        delete it;
    }
}

void Game::makeTree()
{
    root = new Tree;
    QFile file(":/Files/exe/russian_nouns.txt");
    QTextStream readFile(&file);
    bool open = file.open(QIODevice::ReadOnly);  //открываем файл для чтения
    //qDebug()<<open;
    QString line;
    while (!readFile.atEnd())       // метод atEnd() возвращает true, если в потоке больше нет данных для чтения
    {
           line = readFile.readLine();  // метод readLine() считывает одну строку из потока
           root->addString(line);
           //если размер слова == 5, то оно подойдёт для начала игры
           if(line.size() == 5)
           {
               QString* str = new QString(line);
               wordbBaseForNewGame.push_back(str);
           }
    }
    file.close();
}

void Game::makeGraf(const QPoint& point, const QString& letter)
{
    int size = mapIntLetter.size() + 1;
    //запоминаем букву
    mapIntLetter.insert(std::pair<int, QString>(size, letter));
    //вставляем в граф
    std::set<int> set;
    mapIntSet.insert(std::pair<int, std::set<int>>(size, set));
    //формируем смежные вершины в графе
    auto itb = mapIntPoint.begin(), ite = mapIntPoint.end();
    while(itb != ite)
    {
        //проверка, являются ли две точки смежными, если являются, то
        if((abs((*itb).second.x() - point.x()) == 1 && (*itb).second.y() == point.y()) ||
          (abs((*itb).second.y() - point.y()) == 1 && (*itb).second.x() == point.x()))
        {
            //записываем к новой точке уже существующую, как смежную
            auto itNew = mapIntSet.find(size);
            (*itNew).second.insert((*itb).first);
            //записываем к станой точке новую как смежную
            auto itOld = mapIntSet.find((*itb).first);
            (*itOld).second.insert(size);
        }
        itb++;
    }
    //добавляем точку в список точек
    mapIntPoint.insert(std::pair<int, QPoint>(size, point));
}

void Game::removeFromGraf(int x)
{
    mapIntLetter.erase(x);
    mapIntPoint.erase(x);
    mapIntSet.erase(x);
    auto itb = mapIntSet.begin(), ite = mapIntSet.end();
    while(itb != ite)
    {
        (*itb).second.erase(x);
        itb++;
    }
}

QString& Game::makeNewStartWord()
{
    int size = wordbBaseForNewGame.size();
    //генерация случайных чисел от 0 до size-1
    int r = rand() % size;
    //запомнили слово, чтобы не повторялось
    QString str = *wordbBaseForNewGame[r];
    str = str.toUpper();
    userWords.push_back(str);
    return *wordbBaseForNewGame[r];
}

void Game::traversalGraf()
{
    compWord = "";
    compWordCoordinate.clear();
    //перебираем все смежные клетки, ставим в них все буквы
    for(auto itp: pointsForCompSteps)
    {
        qDebug()<<"ДОСТУПНАЯ КЛЕТКА"<<itp;
        //добавим в граф новую вершину
        this->makeGraf(itp, QString("*"));
        int size = mapIntLetter.size();
        //перебираем все буквы
        for(auto itl: lettersBase)
        {
            //меняем на каждой итерации букву у вершины
            mapIntLetter[size] = itl;
            //будем по очереди обходить все вершины графа
            auto itb = mapIntSet.begin(), ite = mapIntSet.end();
            while(itb != ite)
            {
                if(((*itb).first == size) && ((itl == "Й") || (itl == "Ъ") || (itl == "Ы") || (itl == "Ь")))
                {
                    itb++;
                    continue;
                }
                //qDebug()<<"ВЕРШИНА"<<(*itb).first<<"БУКВА"<<itl<<"ИСКОМАЯ ВЕРШИНА"<<size<<"НАХОДИТСЯ "<<itp;
                //vecWord.clear();
                this->findAllCombinations((*itb).first);
                itb++;
                vecWord.clear();
                compWord = "";
                compWordCoordinate.clear();
                //qDebug()<<"ВЫШЛИ!!!!";
            }
        }
        this->removeFromGraf(size);
    }
    this->chooseBestWord();
    //отрисовка поля с новой буквой
}

void Game::findAllCombinations(int x)
{
    bool needToCheck = true;
    //если такая вершина уже была посещена
    for(auto it: vecWord)
    {
        if(x == it)
        {
            return;
        }
    }
        //добавляем в список вершин
        vecWord.push_back(x);
        auto itm = mapIntLetter.find(x);
        //записываем букву
        compWord += (*itm).second;
        //qDebug()<<compWord;
        auto itp = mapIntPoint.find(x);
        //записываем координаты слова
        compWordCoordinate.push_back((*itp).second);
        //если в соответствии с деревом такое слово составить нельзя - возвращаемся назад
        if(root->checkPossibleWord(compWord) == false)
        {
            int wordSize = vecWord.size();
            vecWord.removeLast();
            compWord.remove(wordSize-1, 1);
            compWordCoordinate.removeLast();
            return;
        }
        //если слово такого размера уже нашли, то дальше искать не надо
        for(auto it: wordSize)
        {
            if(it==compWord.size())
            {
                needToCheck = false;
            }
        }

        //проверяем получившуюся строчку, если её размер больше 1 и в нее входит искомая вершина
        //так же запишем координату искомой вершины
        if(needToCheck == true)
        {if(vecWord.size() > 1)
        {
            for(auto it: vecWord)
            {
                if(it == mapIntSet.size())
                {
                    bool gameBase = this->checkWordInUserCompBase(compWord);
                    //qDebug()<<gameBase;
                    if(gameBase == false)
                    {
                            //проверяем найденную строчку в уже найденных словах
                        //qDebug()<<word;
                        bool compBase = root->checkString(compWord);
                        if(compBase == true)
                        {
                            //записываем в список найденных слов
                            allCompWords.insert(std::pair<QString, QVector<QPoint>>(compWord, compWordCoordinate));
                            wordSize.push_back(compWord.size());
                        }

                    }
                    break;
                }
            }
        }
        }

        //организовываем цикл со всеми смежными вершинами
        auto itPair = mapIntSet.find(x);  //нашли по ключу вершину
        int size = (*itPair).second.size();
        //qDebug()<<"У ВЕРШИНЫ" << x<<"СМЕЖНЫХ ВЕРШИН"<<size;
        int count = 0;
        for(auto it: (*itPair).second)
        {
            //qDebug()<<"ВЕРШИНА"<<it;
            count++;
            this->findAllCombinations(it);
            if(size == count)
            {
                int wordSize = vecWord.size();
                vecWord.removeLast();
                if(vecWord.empty())
                {
                    compWord = "";
                    compWordCoordinate.removeLast();
                    //qDebug()<<"СЛОВО ПОСЛЕ ВОЗВРАЩЕНИЯ" << compWord;
                }
                else
                {
                    compWord.remove(wordSize-1, 1);
                    compWordCoordinate.removeLast();
                    //qDebug()<<"СЛОВО ПОСЛЕ ВОЗВРАЩЕНИЯ" << compWord;
                }

                //qDebug()<<"СЛОВО ПОСЛЕ ВОЗВРАЩЕНИЯ" << compWord;
            }
        }

}

void Game::chooseBestWord()
{
    int x = allCompWords.size();
    qDebug() << "НАЙДЕННЫЕ СЛОВА" << x;
    if(x == 0)
    {
        compWord = "";
    }
    else
    {
    auto itb = allCompWords.begin(), ite = allCompWords.end();
    int size = 0;
    while(itb != ite)
    {
        //qDebug() << *itb;
        if((*itb).first.size() > size)
        {
            size = (*itb).first.size();
            compWord = (*itb).first;
            compWordCoordinate = (*itb).second;
        }
        itb++;
    }
    //запомнили найденное слово
    compWords.push_back(compWord);
    //увеличили счет компа
    compScore += compWord.size();
    //удаляем все найденные компом слова
    auto itb2 = allCompWords.begin(), ite2 = allCompWords.end();
    allCompWords.erase(itb2, ite2);
    //очищаем вектор для поиска слова
    vecWord.clear();
    //очищаем вектор размеров
    wordSize.clear();
    }
}

bool Game::checkWordInUserCompBase(const QString& word) //проверка на введение повторяющихся слов
{
    for(auto it: userWords)
    {
        if(word == it)
            return true;
    }
    for(auto it: compWords)
    {
        if(word == it)
            return true;
    }
    return false;
}

bool Game::checkString(const QString& line)
{
    return root->checkString(line);
}

void Game::addUserWord(const QString& word)
{
    userWords.push_back(word);
}

void Game::startNewGame()
{
        //очищаем все слова, найденные игроком
    auto itb1 = userWords.begin(), ite1 = userWords.end();
    userWords.erase(itb1, ite1);
        //очищаем все слова, найденные компьютером
    auto itb2 = compWords.begin(), ite2 = compWords.end();
    compWords.erase(itb2, ite2);
        //очищаем граф и все элементы графа
    auto itb3 = mapIntLetter.begin(), ite3 = mapIntLetter.end();
    mapIntLetter.erase(itb3, ite3);
    auto itb4 = mapIntPoint.begin(), ite4 = mapIntPoint.end();
    mapIntPoint.erase(itb4, ite4);
    auto itb5 = mapIntSet.begin(), ite5 = mapIntSet.end();
    mapIntSet.erase(itb5, ite5);
        //обнуляем счет
    userScore = 0;
    compScore = 0;
}

const QVector<QPoint>& Game::wordCoordinateGet() const
{
    return compWordCoordinate;
}

const QString& Game::compWordGet() const
{
    return compWord;
}

bool Game::GameOver()
{
    if(mapIntLetter.size() == 25)
    {
        return true;
    }
    return false;
}

int Game::compScoreGet()
{
    return compScore;
}

void Game::setUserScore(int score)
{
    userScore += score;
}

int Game::userScoreGet()
{
    return userScore;
}

void Game::setPointsForCompStep(const std::list<QPoint>& points)
{
    pointsForCompSteps = points;
}


